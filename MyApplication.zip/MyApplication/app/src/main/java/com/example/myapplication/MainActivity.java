package com.example.myapplication;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    Button add;
    DatabaseReference databaseTIAS;
    ListView listView;

    List<data> dataList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = (ListView) findViewById(R.id.listView);
        databaseTIAS = FirebaseDatabase.getInstance().getReference("Range");
        dataList = new ArrayList<>();

        add = (Button) findViewById(R.id.add) ;

        add.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                openAddpage();
            }
        });

    }

    @Override
    protected void onStart() {
        super.onStart();

        databaseTIAS.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                dataList.clear();

                for (DataSnapshot dataSnapshot1 : dataSnapshot.getChildren() ){
                    data Data = dataSnapshot1.getValue(data.class);

                    dataList.add(Data);
                }

                DataList adapter = new DataList(MainActivity.this,dataList);
                listView.setAdapter(adapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    public void openAddpage(){
        Intent intent = new Intent(this,add.class);
        startActivity(intent);
    }
}
