package com.example.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class add extends AppCompatActivity {

    //define
    EditText input1;
    EditText  input2;
    EditText  input3;
    Button save;

    //Create database
    DatabaseReference databaseTIAS;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        databaseTIAS = FirebaseDatabase.getInstance().getReference("Range");

        input1 = (EditText) findViewById(R.id.input1);
        input2 = (EditText) findViewById(R.id.input2);
        input3 = (EditText) findViewById(R.id.input3);
        save = (Button) findViewById(R.id.save) ;

        save.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                addData();
            }
        });

    }


    private void addData(){
        String max = input1.getText().toString();
        String min = input2.getText().toString();
        String des = input3.getText().toString();

        if(!TextUtils.isEmpty(max)||!TextUtils.isEmpty(min)||!TextUtils.isEmpty(des)){
            // push data
            String id = databaseTIAS.push().getKey();

            data Range =  new data(id,max,min,des);  //new object

            databaseTIAS.child(id).setValue(Range);

            Toast.makeText(this,"Data added",Toast.LENGTH_LONG).show();
            finish();
        }else{
            Toast.makeText(this,"Do not blank any gap.", Toast.LENGTH_LONG).show();
        }
    }
}
