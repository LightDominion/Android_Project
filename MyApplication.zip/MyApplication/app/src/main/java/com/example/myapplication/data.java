package com.example.myapplication;

//Constructure
public class data {
    String id;
    String max;
    String min;
    String description;

    public data(){

    }

    public data(String id, String max, String min, String description) {
        this.id = id;
        this.max = max;
        this.min = min;
        this.description = description;
    }

    public String getId() {
        return id;
    }

    public String getMax() {
        return max;
    }

    public String getMin() {
        return min;
    }

    public String getDescription() {
        return description;
    }
}
