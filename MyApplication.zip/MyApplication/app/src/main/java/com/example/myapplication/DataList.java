package com.example.myapplication;

import android.app.Activity;
import android.provider.ContactsContract;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class DataList extends ArrayAdapter<data> {

    private Activity context;
    private List<data> dataList;

    public DataList(Activity context, List<data> dataList){
        super(context, R.layout.list_layout, dataList);
        this.context = context;
        this.dataList = dataList;
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();

        View listViewItem = inflater.inflate(R.layout.list_layout,null,true);

        TextView textViewMax = (TextView) listViewItem.findViewById(R.id.maxtx);
        TextView textViewMin = (TextView) listViewItem.findViewById(R.id.mintx);
        TextView textViewdes = (TextView) listViewItem.findViewById(R.id.destx);

        data Data = dataList.get(position);

        textViewMax.setText(Data.getMax());
        textViewMin.setText(Data.getMin());
        textViewdes.setText(Data.getDescription());

        return  listViewItem;
    }
}
